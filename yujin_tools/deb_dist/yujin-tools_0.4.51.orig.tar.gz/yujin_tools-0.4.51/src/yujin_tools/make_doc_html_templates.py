
####################################################################
# Stores the html templates to create index.html
####################################################################

html_header = ['<!DOCTYPE html>',
               '<html>         ',
               '  <head>       ',
               '    <meta charset="UTF-8"/>',
               '    <title> Documents </title>',
               '  </head>      ',
               '  <body>       ',
               '    <h1> Package Lists </h1>',
               ]

html_footer = ['  </body>                     ',
               '</html>                       ',
               ]
